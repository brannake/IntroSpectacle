import React, { Component } from "react";
import SideNavMod from "./SideNavMod";
import {Dropdown, Modal, Button, Navbar, NavItem, Slider, Slide, Footer, Row, Input, Icon, image} from 'react-materialize';

class NavbarCustom extends Component {

  render() {
    return (
    <div>
      Is this thing on??
  </div>
    );
  }
}

export default NavbarCustom;